/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.unideb.inf.prt.gyak11;

import javax.persistence.*;


/**
 *
 * @author Gabi
 */



@Entity
@Table(name="beosztottak")
public class beosztott {
    @Id
    @Column(name="ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="szekv")
    @SequenceGenerator(name="szekv",sequenceName = "szekvencia", allocationSize = 1)
    private int id;
    @Column(name="VEZETEKNEV")
    private String vezeteknev;
    @Column(name="KERESZTNEV")       
    private String keresztnev;
    @Column(name="BEOSZTAS")
    private String beosztas;

    public beosztott(String vezeteknev, String keresztnev, String beosztas) {
        this.vezeteknev = vezeteknev;
        this.keresztnev = keresztnev;
        this.beosztas = beosztas;
    }

    public beosztott() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVezeteknev() {
        return vezeteknev;
    }

    public void setVezeteknev(String vezeteknev) {
        this.vezeteknev = vezeteknev;
    }

    public String getKeresztnev() {
        return keresztnev;
    }

    public void setKeresztnev(String keresztnev) {
        this.keresztnev = keresztnev;
    }

    public String getBeosztas() {
        return beosztas;
    }

    public void setBeosztas(String beosztas) {
        this.beosztas = beosztas;
    }
    
    
    
}
